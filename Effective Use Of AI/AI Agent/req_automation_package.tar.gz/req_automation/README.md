# 📋 Requirements Automation Tool

> Transforms raw client requirements into a structured analysis document and sends a professional email — powered by Google Gemini AI.

---

## What It Does

1. **Reads** raw requirements from `inputs/requirements.txt`
2. **Sends** them to Gemini AI with an engineered prompt
3. **Generates** a structured artifact:
   - Functional Requirements (with priority)
   - Non-Functional Requirements (by category)
   - Risks & Mitigations
   - Assumptions
   - Questions for the Client
4. **Composes** a professional HTML + plain-text email
5. **Sends** it via Gmail SMTP (App Password)
6. **Saves** all outputs locally (JSON, HTML, plain-text)

---

## Architecture

```
[requirements.txt]
       │
       ▼
[input_reader.py]   ←── validates & reads
       │
       ▼
[llm_processor.py]  ──▶ [Gemini API] ──▶ JSON artifact
       │
       ▼
[email_formatter.py]  ──▶ HTML + plain-text email
       │
       ├──▶ [gmail_sender.py]  ──SMTP──▶  Client inbox
       │
       └──▶ outputs/ (JSON, HTML, TXT)
```

---

## Prerequisites

| Requirement | Details |
|---|---|
| Python | 3.12+ (tested on 3.14.5) |
| Google Gemini API Key | [Get one here](https://aistudio.google.com/app/apikey) |
| Gmail App Password | Requires 2FA enabled on Gmail account |

---

## Setup

### 1. Clone & Create Virtual Environment

```bash
git clone <your-repo-url>
cd req_automation
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure Environment Variables

```bash
cp .env.example .env
```

Edit `.env` with your values:

```env
GEMINI_API_KEY=your_gemini_api_key_here
GEMINI_MODEL=gemini-1.5-flash
GMAIL_SENDER=you@gmail.com
GMAIL_APP_PASSWORD=xxxx_xxxx_xxxx_xxxx
GMAIL_RECIPIENT=client@example.com
```

**How to get a Gmail App Password:**
1. Go to [myaccount.google.com](https://myaccount.google.com)
2. Security → 2-Step Verification → App passwords
3. Generate a password for "Mail"
4. Enter the 16-character password (without spaces) in `.env`

### 4. Add Your Requirements

Edit `inputs/requirements.txt` with the client's raw requirements. Example:

```
We need an e-commerce platform where customers can browse products,
add to cart, and pay with credit card or UPI. Orders must be
fulfilled by our warehouse team within 24 hours...
```

### 5. Run

```bash
python src/main.py
```

---

## Output Files

All outputs are saved in `outputs/` with a timestamp:

| File | Description |
|---|---|
| `response_YYYYMMDD_HHMMSS.json` | Raw structured Gemini response |
| `email_draft_YYYYMMDD_HHMMSS.html` | HTML email (open in browser to preview) |
| `email_draft_YYYYMMDD_HHMMSS.txt` | Plain-text email fallback |
| `logs/app.log` | Full execution log |

---

## Project Structure

```
req_automation/
├── .env                    # Your secrets (never commit)
├── .env.example            # Template
├── .gitignore
├── README.md
├── requirements.txt
│
├── inputs/
│   └── requirements.txt    # ← Put client requirements here
│
├── outputs/                # Auto-created
│   ├── response_*.json
│   ├── email_draft_*.html
│   └── email_draft_*.txt
│
├── logs/
│   └── app.log
│
├── prompts/
│   └── requirements_prompt.txt   # Gemini prompt template
│
├── src/
│   ├── config.py           # Environment variable loader
│   ├── input_reader.py     # File reader & validator
│   ├── llm_processor.py    # Gemini API + response parser
│   ├── email_formatter.py  # HTML/text email builder
│   ├── gmail_sender.py     # SMTP sender
│   └── main.py             # Orchestrator entry point
│
└── tests/
    ├── test_input_reader.py
    ├── test_llm_processor.py
    ├── test_email_formatter.py
    └── test_gmail_sender.py
```

---

## Running Tests

```bash
# All tests
python -m pytest tests/ -v

# With coverage
python -m pytest tests/ --cov=src --cov-report=term-missing

# Single module
python -m pytest tests/test_llm_processor.py -v
```

**Test coverage by module:**

| Module | Scenarios Covered |
|---|---|
| `input_reader` | Happy path, missing file, empty file, short content, directory path, permission error |
| `llm_processor` | Happy path, retry logic, all retries exhausted, invalid JSON, schema mismatch, missing prompt |
| `email_formatter` | Full artifact, empty artifact, missing info block, CC recipients, custom greeting |
| `gmail_sender` | Success, auth failure (no retry), network retry, timeout, CC delivery |

---

## Configuration Reference

| Variable | Required | Default | Description |
|---|---|---|---|
| `GEMINI_API_KEY` | ✅ | — | Gemini API key |
| `GEMINI_MODEL` | ❌ | `gemini-1.5-flash` | Model name |
| `GEMINI_TEMPERATURE` | ❌ | `0.3` | 0.0–1.0, lower = more structured |
| `GEMINI_MAX_TOKENS` | ❌ | `8192` | Max response tokens |
| `GMAIL_SENDER` | ✅ | — | Sender Gmail address |
| `GMAIL_APP_PASSWORD` | ✅ | — | 16-char App Password |
| `GMAIL_RECIPIENT` | ✅ | — | Client email address |
| `GMAIL_CC` | ❌ | `` | Comma-separated CC addresses |
| `LOG_LEVEL` | ❌ | `INFO` | `DEBUG\|INFO\|WARNING\|ERROR` |
| `OUTPUT_DIR` | ❌ | `outputs` | Where to save outputs |
| `REQUIREMENTS_FILE` | ❌ | `requirements.txt` | Input filename |

---

## Error Handling

| Error | Behaviour |
|---|---|
| Missing `.env` variable | Fails immediately with a clear message |
| `requirements.txt` not found | `FileNotFoundError` with path hint |
| Requirements too short | `ValueError` with minimum length info |
| Gemini API error | Retries up to 3× with exponential backoff |
| Gemini returns invalid JSON | Retries up to 3× |
| Gmail auth failure | Fails immediately (no retry) with setup guidance |
| SMTP network error | Retries up to 3× |
| All retries exhausted | Saves outputs locally; logs error; exits with code 1 |

---

## Security Notes

- **Never commit `.env`** — it is in `.gitignore`
- The App Password is never logged
- Use `.env.example` to share config structure with teammates
- Rotate your App Password if it is ever exposed

---

## Extending the Tool

**Change the LLM model:** Set `GEMINI_MODEL=gemini-1.5-pro` in `.env`

**Add more email recipients:** Set `GMAIL_CC=pm@company.com,cto@company.com`

**Customise the prompt:** Edit `prompts/requirements_prompt.txt` — the `{requirements}` placeholder is where your input is injected

**Save to a database:** Add a `storage.py` module and call it from `main.py` after `_save_outputs()`

---

## License

MIT
