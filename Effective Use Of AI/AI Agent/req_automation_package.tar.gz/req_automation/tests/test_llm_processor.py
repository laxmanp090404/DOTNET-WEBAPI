"""
tests/test_llm_processor.py — Unit tests for llm_processor.py
"""

import json
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch

from src.config import GeminiConfig
from src.llm_processor import (
    RequirementsArtifact,
    _parse_response,
    _strip_markdown_fences,
    _validate_schema,
    _build_prompt,
    process_requirements,
)

# ── Fixtures ──────────────────────────────────────────────────────────────────

VALID_JSON: dict = {
    "functional_requirements": [
        {"id": "FR-01", "title": "Login", "description": "Users can log in.", "priority": "High"}
    ],
    "non_functional_requirements": [
        {"id": "NFR-01", "category": "Security", "description": "TLS encryption."}
    ],
    "risks": [
        {"id": "R-01", "risk": "Data breach", "severity": "High", "mitigation": "Encrypt at rest."}
    ],
    "assumptions": [
        {"id": "A-01", "assumption": "Users have internet access."}
    ],
    "questions_for_client": [
        {"id": "Q-01", "question": "SSO required?", "rationale": "Affects auth scope."}
    ],
    "missing_information": [],
    "summary": "A simple login system.",
}

VALID_JSON_STR = json.dumps(VALID_JSON)


@pytest.fixture
def gemini_config() -> GeminiConfig:
    return GeminiConfig(
        api_key="fake-key",
        model="gemini-1.5-flash",
        temperature=0.3,
        max_tokens=1024,
    )


@pytest.fixture
def prompt_file(tmp_path: Path) -> Path:
    f = tmp_path / "prompt.txt"
    f.write_text("Analyse: {requirements}", encoding="utf-8")
    return f


# ── _strip_markdown_fences ────────────────────────────────────────────────────

class TestStripMarkdownFences:
    def test_strips_json_fence(self) -> None:
        raw = "```json\n{\"key\": \"val\"}\n```"
        assert _strip_markdown_fences(raw) == '{"key": "val"}'

    def test_strips_plain_fence(self) -> None:
        raw = "```\n{\"key\": \"val\"}\n```"
        assert _strip_markdown_fences(raw) == '{"key": "val"}'

    def test_no_fence_unchanged(self) -> None:
        raw = '{"key": "val"}'
        assert _strip_markdown_fences(raw) == '{"key": "val"}'

    def test_whitespace_trimmed(self) -> None:
        raw = "  \n  {\"key\": \"val\"}  \n  "
        assert _strip_markdown_fences(raw) == '{"key": "val"}'


# ── _parse_response ───────────────────────────────────────────────────────────

class TestParseResponse:
    def test_parses_valid_json(self) -> None:
        result = _parse_response(VALID_JSON_STR)
        assert result["summary"] == "A simple login system."

    def test_raises_on_invalid_json(self) -> None:
        with pytest.raises(ValueError, match="invalid JSON"):
            _parse_response("not json at all {{{")

    def test_raises_on_empty_string(self) -> None:
        with pytest.raises(ValueError):
            _parse_response("")

    def test_handles_markdown_fenced_json(self) -> None:
        fenced = f"```json\n{VALID_JSON_STR}\n```"
        result = _parse_response(fenced)
        assert "functional_requirements" in result


# ── _validate_schema ──────────────────────────────────────────────────────────

class TestValidateSchema:
    def test_passes_valid_schema(self) -> None:
        _validate_schema(VALID_JSON)  # Should not raise

    def test_raises_on_missing_key(self) -> None:
        incomplete = {k: v for k, v in VALID_JSON.items() if k != "risks"}
        with pytest.raises(ValueError, match="missing required fields"):
            _validate_schema(incomplete)

    def test_raises_on_empty_dict(self) -> None:
        with pytest.raises(ValueError, match="missing required fields"):
            _validate_schema({})


# ── _build_prompt ─────────────────────────────────────────────────────────────

class TestBuildPrompt:
    def test_injects_requirements(self) -> None:
        template = "Analyse: {requirements}"
        result = _build_prompt(template, "Need a login system.")
        assert result == "Analyse: Need a login system."

    def test_raises_if_placeholder_missing(self) -> None:
        template = "Analyse this: ..."
        with pytest.raises(ValueError, match="placeholder"):
            _build_prompt(template, "some requirements")


# ── process_requirements (integration with mocked Gemini) ────────────────────

class TestProcessRequirements:
    def _make_mock_client(self, response_text: str) -> MagicMock:
        """Helper: build a mock genai.Client whose models.generate_content returns response_text."""
        mock_response = MagicMock()
        mock_response.text = response_text
        mock_client = MagicMock()
        mock_client.models.generate_content.return_value = mock_response
        return mock_client

    def test_happy_path(
        self, gemini_config: GeminiConfig, prompt_file: Path
    ) -> None:
        mock_client = self._make_mock_client(VALID_JSON_STR)

        with patch("src.llm_processor.genai.Client", return_value=mock_client):
            artifact, raw_json = process_requirements(
                requirements="We need a login system with user management.",
                gemini_config=gemini_config,
                prompt_file=prompt_file,
            )

        assert isinstance(artifact, RequirementsArtifact)
        assert len(artifact.functional_requirements) == 1
        assert artifact.functional_requirements[0].id == "FR-01"
        assert artifact.summary == "A simple login system."
        assert json.loads(raw_json)["summary"] == "A simple login system."

    def test_retries_on_api_error_then_succeeds(
        self, gemini_config: GeminiConfig, prompt_file: Path
    ) -> None:
        mock_response = MagicMock()
        mock_response.text = VALID_JSON_STR
        mock_client = MagicMock()
        # Fail twice, succeed third time
        mock_client.models.generate_content.side_effect = [
            Exception("Transient error"),
            Exception("Transient error"),
            mock_response,
        ]

        with patch("src.llm_processor.genai.Client", return_value=mock_client):
            with patch("src.llm_processor.time.sleep"):
                artifact, _ = process_requirements(
                    requirements="Login system with user authentication.",
                    gemini_config=gemini_config,
                    prompt_file=prompt_file,
                )
        assert isinstance(artifact, RequirementsArtifact)

    def test_raises_runtime_error_after_all_retries_fail(
        self, gemini_config: GeminiConfig, prompt_file: Path
    ) -> None:
        mock_client = MagicMock()
        mock_client.models.generate_content.side_effect = Exception("API down")

        with patch("src.llm_processor.genai.Client", return_value=mock_client):
            with patch("src.llm_processor.time.sleep"):
                with pytest.raises(RuntimeError, match="All.*attempts failed"):
                    process_requirements(
                        requirements="A system for managing inventory and orders.",
                        gemini_config=gemini_config,
                        prompt_file=prompt_file,
                    )

    def test_raises_on_invalid_json_response(
        self, gemini_config: GeminiConfig, prompt_file: Path
    ) -> None:
        mock_client = self._make_mock_client("This is not JSON at all.")

        with patch("src.llm_processor.genai.Client", return_value=mock_client):
            with patch("src.llm_processor.time.sleep"):
                with pytest.raises(RuntimeError):
                    process_requirements(
                        requirements="We need a payment processing system.",
                        gemini_config=gemini_config,
                        prompt_file=prompt_file,
                    )

    def test_raises_file_not_found_for_missing_prompt(
        self, gemini_config: GeminiConfig, tmp_path: Path
    ) -> None:
        missing_prompt = tmp_path / "no_prompt.txt"
        with pytest.raises(FileNotFoundError):
            process_requirements(
                requirements="Some requirements about the system.",
                gemini_config=gemini_config,
                prompt_file=missing_prompt,
            )
