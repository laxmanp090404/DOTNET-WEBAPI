"""
tests/test_email_formatter.py — Unit tests for email_formatter.py
"""

import pytest
from src.llm_processor import (
    RequirementsArtifact,
    FunctionalRequirement,
    NonFunctionalRequirement,
    Risk,
    Assumption,
    ClientQuestion,
)
from src.email_formatter import format_email, EmailPayload


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def full_artifact() -> RequirementsArtifact:
    return RequirementsArtifact(
        functional_requirements=[
            FunctionalRequirement("FR-01", "User Login", "Users can log in.", "High"),
            FunctionalRequirement("FR-02", "Dashboard", "Overview stats.", "Medium"),
        ],
        non_functional_requirements=[
            NonFunctionalRequirement("NFR-01", "Security", "TLS everywhere."),
        ],
        risks=[
            Risk("R-01", "Data breach", "High", "Encrypt at rest."),
        ],
        assumptions=[
            Assumption("A-01", "Users have email addresses."),
        ],
        questions_for_client=[
            ClientQuestion("Q-01", "SSO required?", "Affects auth scope."),
        ],
        missing_information=["No SLA defined."],
        summary="A system for managing user sessions.",
    )


@pytest.fixture
def empty_artifact() -> RequirementsArtifact:
    return RequirementsArtifact()


# ── format_email happy path ───────────────────────────────────────────────────

class TestFormatEmailHappyPath:
    def test_returns_email_payload(self, full_artifact: RequirementsArtifact) -> None:
        result = format_email(
            artifact=full_artifact,
            sender="sender@gmail.com",
            recipient="client@example.com",
            cc=[],
        )
        assert isinstance(result, EmailPayload)

    def test_subject_contains_date(self, full_artifact: RequirementsArtifact) -> None:
        result = format_email(
            artifact=full_artifact,
            sender="sender@gmail.com",
            recipient="client@example.com",
            cc=[],
        )
        assert "Requirements Analysis" in result.subject

    def test_html_contains_fr_id(self, full_artifact: RequirementsArtifact) -> None:
        result = format_email(
            artifact=full_artifact,
            sender="s@g.com",
            recipient="r@e.com",
            cc=[],
        )
        assert "FR-01" in result.html_body
        assert "FR-02" in result.html_body

    def test_html_contains_nfr(self, full_artifact: RequirementsArtifact) -> None:
        result = format_email(
            artifact=full_artifact,
            sender="s@g.com",
            recipient="r@e.com",
            cc=[],
        )
        assert "NFR-01" in result.html_body
        assert "TLS everywhere." in result.html_body

    def test_html_contains_risk(self, full_artifact: RequirementsArtifact) -> None:
        result = format_email(
            artifact=full_artifact,
            sender="s@g.com",
            recipient="r@e.com",
            cc=[],
        )
        assert "Data breach" in result.html_body
        assert "Encrypt at rest." in result.html_body

    def test_html_contains_summary(self, full_artifact: RequirementsArtifact) -> None:
        result = format_email(
            artifact=full_artifact,
            sender="s@g.com",
            recipient="r@e.com",
            cc=[],
        )
        assert "A system for managing user sessions." in result.html_body

    def test_html_contains_missing_info_block(
        self, full_artifact: RequirementsArtifact
    ) -> None:
        result = format_email(
            artifact=full_artifact,
            sender="s@g.com",
            recipient="r@e.com",
            cc=[],
        )
        assert "No SLA defined." in result.html_body
        assert "Information Gaps" in result.html_body

    def test_text_body_contains_all_sections(
        self, full_artifact: RequirementsArtifact
    ) -> None:
        result = format_email(
            artifact=full_artifact,
            sender="s@g.com",
            recipient="r@e.com",
            cc=[],
        )
        for section in [
            "FUNCTIONAL REQUIREMENTS",
            "NON-FUNCTIONAL REQUIREMENTS",
            "RISKS",
            "ASSUMPTIONS",
            "QUESTIONS",
        ]:
            assert section in result.text_body

    def test_sender_and_recipient_set(self, full_artifact: RequirementsArtifact) -> None:
        result = format_email(
            artifact=full_artifact,
            sender="me@gmail.com",
            recipient="them@example.com",
            cc=["boss@example.com"],
        )
        assert result.sender == "me@gmail.com"
        assert result.recipient == "them@example.com"
        assert result.cc == ["boss@example.com"]

    def test_custom_recipient_name_in_greeting(
        self, full_artifact: RequirementsArtifact
    ) -> None:
        result = format_email(
            artifact=full_artifact,
            sender="s@g.com",
            recipient="r@e.com",
            cc=[],
            recipient_name="Alice",
        )
        assert "Alice" in result.html_body
        assert "Alice" in result.text_body


# ── Empty artifact ────────────────────────────────────────────────────────────

class TestFormatEmailEmptyArtifact:
    def test_empty_artifact_still_renders(
        self, empty_artifact: RequirementsArtifact
    ) -> None:
        result = format_email(
            artifact=empty_artifact,
            sender="s@g.com",
            recipient="r@e.com",
            cc=[],
        )
        # Should not raise; should have valid HTML structure
        assert "<!DOCTYPE html>" in result.html_body
        assert "REQUIREMENTS ANALYSIS" in result.text_body

    def test_no_missing_info_block_when_empty(
        self, empty_artifact: RequirementsArtifact
    ) -> None:
        result = format_email(
            artifact=empty_artifact,
            sender="s@g.com",
            recipient="r@e.com",
            cc=[],
        )
        assert "Information Gaps" not in result.html_body
