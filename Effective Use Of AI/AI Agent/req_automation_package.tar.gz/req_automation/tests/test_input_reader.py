"""
tests/test_input_reader.py — Unit tests for input_reader.py
"""

import pytest
from pathlib import Path
from unittest.mock import patch, mock_open

from src.input_reader import read_requirements


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_file(tmp_path: Path, content: str, name: str = "requirements.txt") -> Path:
    f = tmp_path / name
    f.write_text(content, encoding="utf-8")
    return f


# ── Happy Path ────────────────────────────────────────────────────────────────

class TestReadRequirementsHappyPath:
    def test_returns_stripped_content(self, tmp_path: Path) -> None:
        content = "  We need a comprehensive inventory management and tracking system.  \n  "
        f = _make_file(tmp_path, content)
        result = read_requirements(f)
        assert result == "We need a comprehensive inventory management and tracking system."

    def test_accepts_long_content(self, tmp_path: Path) -> None:
        content = "A" * 500
        f = _make_file(tmp_path, content)
        result = read_requirements(f)
        assert len(result) == 500

    def test_preserves_newlines_in_content(self, tmp_path: Path) -> None:
        content = "Line one.\nLine two.\nLine three describing the system in detail."
        f = _make_file(tmp_path, content)
        result = read_requirements(f)
        assert "\n" in result

    def test_accepts_exactly_minimum_length(self, tmp_path: Path) -> None:
        content = "X" * 50  # exactly at minimum
        f = _make_file(tmp_path, content)
        result = read_requirements(f)
        assert len(result) == 50


# ── File Not Found ────────────────────────────────────────────────────────────

class TestReadRequirementsFileNotFound:
    def test_raises_file_not_found(self, tmp_path: Path) -> None:
        missing = tmp_path / "does_not_exist.txt"
        with pytest.raises(FileNotFoundError, match="not found"):
            read_requirements(missing)

    def test_error_message_includes_path(self, tmp_path: Path) -> None:
        missing = tmp_path / "ghost.txt"
        with pytest.raises(FileNotFoundError) as exc_info:
            read_requirements(missing)
        assert "ghost.txt" in str(exc_info.value)


# ── Empty / Short Content ─────────────────────────────────────────────────────

class TestReadRequirementsContentValidation:
    def test_raises_on_empty_file(self, tmp_path: Path) -> None:
        f = _make_file(tmp_path, "")
        with pytest.raises(ValueError, match="empty"):
            read_requirements(f)

    def test_raises_on_whitespace_only_file(self, tmp_path: Path) -> None:
        f = _make_file(tmp_path, "   \n\n\t  ")
        with pytest.raises(ValueError, match="empty"):
            read_requirements(f)

    def test_raises_on_too_short_content(self, tmp_path: Path) -> None:
        f = _make_file(tmp_path, "Too short")  # < 50 chars
        with pytest.raises(ValueError, match="too short"):
            read_requirements(f)

    def test_raises_on_49_char_content(self, tmp_path: Path) -> None:
        f = _make_file(tmp_path, "X" * 49)
        with pytest.raises(ValueError, match="too short"):
            read_requirements(f)

    def test_raises_if_path_is_directory(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="not a file"):
            read_requirements(tmp_path)


# ── Permission Error ──────────────────────────────────────────────────────────

class TestReadRequirementsPermissionError:
    def test_raises_permission_error(self, tmp_path: Path) -> None:
        f = _make_file(tmp_path, "content")
        # Patch read_text to simulate permission denied
        with patch.object(Path, "read_text", side_effect=PermissionError("denied")):
            with pytest.raises(PermissionError, match="permission denied"):
                read_requirements(f)
